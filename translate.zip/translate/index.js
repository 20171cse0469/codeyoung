//author nitin gautam   ||  20171cse0469        ||  presidency university
//open code in visual studion choose new terminal and wirte code node index.js   press enter 

const http = require("http");//create a server object
var express = require ("express");//cache server
var os=require('os');
var fs=require('fs');
const server = http.createServer((req,res)=> {//created a constent variable server and called method createServer and pased callback function and passed 2 by default fuction request,response 
    res.end("listening from other side");//this line is for sending response
});

server.listen(8000,"127.0.0.1",()=>{//listening request on port 8000
var clientId = "FREE_TRIAL_ACCOUNT";
var clientSecret = "PUBLIC_SECRET";
var fromLang = "en";//from which language we have to translate
var toLang = "kn";//to which language we are transalting we can here we are using iso codes 
//*****iso codes ***********   
//hindi="hi", english="en", tamil="ta",kannada="kn" and so on..................
var text = "hello";// text to be translated

var jsonPayload = JSON.stringify({
    fromLang: fromLang,
    toLang: toLang,
    text: text
});

var options = {
    hostname: "api.whatsmate.net",
    port: 80,
    path: "/v1/translation/translate",
    method: "POST",
    headers: {
        "Content-Type": "application/json",
        "X-WM-CLIENT-ID": clientId,
        "X-WM-CLIENT-SECRET": clientSecret,
        "Content-Length": Buffer.byteLength(jsonPayload)
    }
};

var request = new http.ClientRequest(options);
request.end(jsonPayload);

request.on('response', function (response) {
    response.setEncoding('utf8');
    response.on('data', function (chunk) {
        console.log('Translated text:'+fromLang,"to\t"+toLang);
        console.log(chunk);
    });
});
var express = require ("express");//cache server
    console.log("listening to port no 8000");
});